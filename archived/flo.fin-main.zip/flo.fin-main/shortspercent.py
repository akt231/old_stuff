# -*- coding: utf-8 -*-
"""
Created on Sun Dec 19 16:35:48 2021

@author: afolabi
"""

import yfinance as yf
import pandas as pd
import numpy as np
from time import time, sleep
import datetime
from tqdm import tqdm
import math

#import numpy as np

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

Tickers1=['iwm']

Tickers = ['brtx','gree','sxtc',
         'VCF','NVEC','CPHC','OVBC','LARK','BOTJ','CHMG','USEG','UG',
         'SYTA','ARTW','VFL','UNB','ALAC','HMNF','WAFU','AEHL','GFED',
         'OPHC','OPNT','WSTG','SGMA','AE','EGF','FMY','INDP','CSPI','IOR',
         'NATH','LLL', 'RMED','GRF','LEDS','DXR','HIHO','MRM','AHPI','DTST',
         'PNBK','NXN','AWX','STRT','ISDR','SMIT','ALTM','NEN','PDEX','UTMD',
         'NWLI','WINA', 'DUOT','NVR','CFFI','ACU','AUBN','ARKR','ESBK','CARV',
         'TAYD','JCTCF','AGIL','PATI','ELSE','FCAP','TRT','PW','UBOH','FFHL',
         'RMBL','HFBL', 'DHIL','PFIN','SBET','WTM','IROQ','LTRPB','HSON','BBLG',
         'AIRT','MSVB','GLBZ','JAN','SAL','SVFD','AINC','KEQU','EMCF','LRFC',
         'PFX','NSYS','EDRY','SZC','SFBC','RAND','CLWT','NSEC','KSPN','GBNY',
         'BCACU','RBCN','ESP','SVT','NCSM','NOM','SNOA','HSDT','UUU','JRJC',
         'TTP','INTG','SRV','SUMR','HIFS','MXC','FEMY','BH','AAMC','MAYS','PNRG',
         'MARPS','IKNX','TSRI','CKX','MTEX','ITIC','MTR','BDL','NDP','RHE','ATRI',
         'MXE','ISIG','WVFC','BHV','LIVE','ACY','CNTX','GYRO','VBFC','DJCO','COHN',
         'SEB','CVR','BRTX','DIT','mitq'
          ]
   
Ticker=[
#'EDU','KGC','SWN','TNXP','ABEV',
#'NCLH','ZNGA','TAL','AUY','GOLD','PLUG','EPD','X','JETS','HRTX','RIG','GEVO','SABR','WU','HAL','SRNE','TEVA','SLB',
#'KHC','SPPI','HST','AMRS','PERI','bldp','SPWR','MUX','AGEN','MGI','GENE',
#'YPF','EWA','ELAN','AMLP','MNKD','EXK','IRWD','MAT','NWL','DISH','SBS','INFI','WTI','DOC','FRSH','AUY','MGI','DOC','ELAN','AMLP','ELEX','MNKD',
#'AGI','PTEN','MBT','DHT','SCHE','CC','OIS','MGI','DOC','ELAN','AUY','PTEN','MBT','DHT','SCHE','CC','OIS','YANG','HP','STOR','AEZS','IMMR','RGS','NMR','DOG','ATRS','ARCO',
#'DK','TGI','NCMI','GGAL','DV'
]
tickers_data= {} # empty dictionary
for ticker in Tickers:

        print('****************************************************************')
        print(f'working on {ticker} now:')
        print('****************************************************************')
        ticker_object = yf.Ticker(ticker)
        data12 = yf.download(ticker,
                             #start="2021-12-01", end="2021-12-18",
                             period="1mo",
                             interval="2m", asynchronous=True, retry=20, status_forcelist=[404, 429, 500, 502, 503, 504])
        #start="2021-11-22", end="2021-11-27
        #start="2021-11-25", end="2021-12-03"
        #period="1m"
        prepost=False,
        data12['Symbol'] = ticker
       #=========volatility===========================================================
        Alength=0
        effectiveLen=math.ceil((Alength+1)/2)
        data12['volatile']=data12['High']+data12['Low']+data12['Close']+data12['Open']
        data12['volatile']=np.tan(data12['volatile'].astype(float))
        # shows the profit range
        Range=(data12['High']-data12['Low'])*100/data12['Low']
       
        #=========== Dataframe selecion================================================
        data12.pop('Open')
        data12.pop('Close')
        data12.pop('Low')
        
       # volatility criteria showing stock to move in the future based on the volatility value
        Volatility=data12.loc[lambda data12: data12['volatile']>30, :]
       # volume criteria showing stock to move based on volume amount
        Volume=data12.loc[lambda data12: data12['Volume']>100000, :]
       
        temp = pd.DataFrame.from_dict(ticker_object.info, orient="index")
        temp.reset_index(inplace=True)
        temp.columns =['attribute','recent']
        #["symbol ", "sharesShort","floatShares","dateShortInterest","shortPercentOfFloat","sharesShortPriorMonth","regularMarketDayHigh","averageVolume10days",'regularMarketVolume ','dayLow']
        tickers_data[ticker] = temp
        combined_data = pd.concat(tickers_data)
        combined_data = combined_data.reset_index()
        del combined_data["level_1"] # clean up unnecessary column
        combined_data.columns = ["Ticker", "Attribute", "Recent"] # update column names
        averageVolume10days = combined_data[combined_data["Attribute"]=="averageVolume10days"].reset_index()
        del averageVolume10days["index"] # clean up unnecessary column
        sharesOutstanding= combined_data[combined_data["Attribute"]=="sharesOutstanding"].reset_index()
        del sharesOutstanding["index"] # clean up unnecessary column
       
        sharesShort= combined_data[combined_data["Attribute"]=="sharesShort"].reset_index()
        del sharesShort["index"] # clean up unnecessary column
       
        shortPercentOfFloat=pd.DataFrame( combined_data[combined_data["Attribute"]=="shortPercentOfFloat"].reset_index())
        del shortPercentOfFloat["index"] # clean up unnecessary column
       
        print(shortPercentOfFloat)
       #print(Volume)
       #print(Volatility)
       #print(sharesOutstanding)
       #print(sharesShort)
       #print(Range)
      
