# 12Data_getTickerData
Code for getting Stock Ticker Data from 12Data
